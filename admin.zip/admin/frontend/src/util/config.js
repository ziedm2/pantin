export const baseURL = "https://yourdomain.com/";
export const secretKey = "ENTER_YOUR_KEY";
export const projectName = "ENTER_PROJECT_NAME";
