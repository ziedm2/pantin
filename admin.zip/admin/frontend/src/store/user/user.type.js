// GET_USER
export const GET_USER = "GET_USER";

//  get user profile
export const GET_USER_PROFILE = "GET_USER_PROFILE";

// user block
export const GET_USER_BLOCK = "GET_USER_BLOCK";

// get user history
export const GET_USER_HISTORY = "GET_USER_HISTORY";

// UPDATE_HOST_COIN
export const UPDATE_USER_COIN = "UPDATE_USER_COIN";
// get user followers list

export const GET_USER_FOLLOWERS_LIST = "GET_USER_FOLLOWERS_LIST";

// get user following  list

export const GET_USER_FOLLOWING_LIST = "GET_USER_FOLLOWING_LIST";

export const SHOW_IMAGE_DIALOGUE = "SHOW_IMAGE_DIALOGUE";

export const CLOSE_IMAGE_DIALOGUE = "CLOSE_IMAGE_DIALOGUE";

// get user post details

export const GET_USER_POST_DETAILS = "GET_USER_POST_DETAILS";

// fakeUser Live Switch

export const LIVE_SWITCH = "LIVE_SWITCH";
