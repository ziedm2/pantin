// get dashboard

export const GET_DASHBOARD ="GET_DASHBOARD"


// get analcite data

export const GET_ANALCITE ="GET_ANALCITE"
