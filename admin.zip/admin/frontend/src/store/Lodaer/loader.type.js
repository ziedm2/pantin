// OPEN LOADER
export const LOADER_OPEN ="LOADER_OPEN"

// close loader
export const CLOSE_LOADER ="CLOSE_LOADER"