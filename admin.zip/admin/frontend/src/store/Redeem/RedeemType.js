// get redeem
export const GET_REDEEM = "GET_REDEEM";

// accepted redeem

export const ACCEPT_REDEEM = ".ACCEPT_REDEEM";
