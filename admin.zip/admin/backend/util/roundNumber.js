exports.roundNumber = (data) => {
  const number = Math.floor(data);
  return number;
};
