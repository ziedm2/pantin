export const baseURL = "https://yourdomain.com";
export const projectName = "YOUR_PROJECT_NAME";
